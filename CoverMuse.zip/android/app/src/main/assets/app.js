const $ = (id) => document.getElementById(id);
const canvas = $('coverCanvas');
const ctx = canvas.getContext('2d');
const W = canvas.width, H = canvas.height;

const familyNames = [
  'Abril Fatface','Alegreya','Alegreya Sans','Alfa Slab One','Alice','Amatic SC','Anton','Archivo','Archivo Black','Arimo','Arvo','Asap','Assistant','Bangers','Barlow','Barlow Condensed','Bebas Neue','Bitter','Bodoni Moda','Bree Serif','Cabin','Cabin Condensed','Cardo','Catamaran','Cinzel','Cormorant','Cormorant Garamond','Crimson Pro','DM Sans','DM Serif Display','Domine','EB Garamond','Exo 2','Figtree','Fira Sans','Fjalla One','Francois One','Frank Ruhl Libre','Gelasio','Gloria Hallelujah','Great Vibes','Heebo','IBM Plex Sans','IBM Plex Serif','Inconsolata','Inter','Josefin Sans','Josefin Slab','Kalam','Kanit','Karla','Kaushan Script','Lato','Libre Baskerville','Libre Franklin','Lilita One','Lobster','Lora','Manrope','Merriweather','Merriweather Sans','Montserrat','Montserrat Alternates','Mukta','Noto Sans','Noto Serif','Nunito','Nunito Sans','Old Standard TT','Open Sans','Oswald','Outfit','Overpass','Pacifico','Pathway Gothic One','Patua One','Permanent Marker','Playfair Display','Plus Jakarta Sans','Poppins','Prata','Prompt','PT Sans','PT Serif','Quattrocento','Quicksand','Raleway','Roboto','Roboto Condensed','Roboto Mono','Roboto Slab','Rokkitt','Rubik','Sacramento','Saira Condensed','Satisfy','Shadows Into Light','Signika','Slabo 27px','Source Sans 3','Source Serif 4','Space Grotesk','Spectral','Teko','Titillium Web','Ubuntu','Unbounded','Vollkorn','Work Sans','Yanone Kaffeesatz','Zilla Slab','Cormorant Infant','DM Mono','Gowun Batang','Italiana','Jost','Lexend','Marcellus','Newsreader','Orbitron','Philosopher','Righteous','Sen',
  'Alex Brush','Allura','Arizonia','Bad Script','Bilbo','Bilbo Swash Caps','Birthstone','Bonheur Royale','Calligraffitti','Cedarville Cursive','Charm','Charmonman','Clicker Script','Cookie','Courgette','Damion','Dancing Script','Dawning of a New Day','Ephesis','Euphoria Script','Felipa','Fleur De Leah','Gwendolyn','Herr Von Muellerhoff','Homemade Apple','Italianno','Jim Nightshade','Kristi','La Belle Aurore','League Script','Lovers Quarrel','Marck Script','Mea Culpa','Meddon','Meie Script','Monsieur La Doulaise','MonteCarlo','Moon Dance','Mrs Saint Delafield','Mrs Sheppards','Neonderthaw','Oooh Baby','Parisienne','Petit Formal Script','Pinyon Script','Qwigley','Rochester','Rouge Script','Ruthie','Send Flowers','Sofia','Splash','Stalemate','Tangerine','The Nautigal','Waterfall','WindSong','Yellowtail','Zeyada','Bellefair','Cinzel Decorative','Cormorant SC','DM Serif Text','Forum','Fraunces','GFS Didot','Instrument Serif','Libre Caslon Display','Libre Caslon Text','Lustria','Noto Serif Display','Oranienbaum','Poiret One','Rufina','Sorts Mill Goudy','Tenor Sans','Vidaloka','Yeseva One','Caveat','Crimson Text'
];
const scriptFonts = new Set(['Great Vibes','Gloria Hallelujah','Kalam','Kaushan Script','Lobster','Pacifico','Permanent Marker','Sacramento','Satisfy','Shadows Into Light','Amatic SC','Alex Brush','Allura','Arizonia','Bad Script','Bilbo','Bilbo Swash Caps','Birthstone','Bonheur Royale','Calligraffitti','Cedarville Cursive','Charm','Charmonman','Clicker Script','Cookie','Courgette','Damion','Dancing Script','Dawning of a New Day','Ephesis','Euphoria Script','Felipa','Fleur De Leah','Gwendolyn','Herr Von Muellerhoff','Homemade Apple','Italianno','Jim Nightshade','Kristi','La Belle Aurore','League Script','Lovers Quarrel','Marck Script','Mea Culpa','Meddon','Meie Script','Monsieur La Doulaise','MonteCarlo','Moon Dance','Mrs Saint Delafield','Mrs Sheppards','Neonderthaw','Oooh Baby','Parisienne','Petit Formal Script','Pinyon Script','Qwigley','Rochester','Rouge Script','Ruthie','Send Flowers','Sofia','Splash','Stalemate','Tangerine','The Nautigal','Waterfall','WindSong','Yellowtail','Zeyada','Caveat']);
const elegantFonts = new Set(['Bodoni Moda','Cardo','Cinzel','Cormorant','Cormorant Garamond','Crimson Pro','DM Serif Display','EB Garamond','Frank Ruhl Libre','Gelasio','Italiana','Libre Baskerville','Lora','Marcellus','Newsreader','Old Standard TT','Playfair Display','Prata','Quattrocento','Source Serif 4','Spectral','Vollkorn','Zilla Slab','Cormorant Infant','Gowun Batang','Philosopher','Bellefair','Cinzel Decorative','Cormorant SC','DM Serif Text','Forum','Fraunces','GFS Didot','Instrument Serif','Libre Caslon Display','Libre Caslon Text','Lustria','Noto Serif Display','Oranienbaum','Poiret One','Rufina','Sorts Mill Goudy','Tenor Sans','Vidaloka','Yeseva One','Crimson Text']);
const fonts = familyNames.map((name, i) => ({
  name,
  css: `'${name}', ${/Serif|Garamond|Bodoni|Baskerville|Lora|Merriweather|Cardo|Cinzel|Prata|Vollkorn|Spectral|Alice|Domine|Gelasio|Marcellus|Newsreader|Philosopher/.test(name) ? 'serif' : 'sans-serif'}`,
  category: scriptFonts.has(name) ? 'Script' : elegantFonts.has(name) ? 'Elegant' : i % 3 === 0 ? 'Display' : i % 3 === 1 ? 'Modern' : 'Classic'
}));

const baseLayer = { size: 80, spacing: 3, line: 1.06, align: 'center', position: 'center', vertical: 'custom', color: '#ffffff', shadow: true, outline: false, caps: false, bold: false, italic: false, underline: false };
const state = {
  image: null, imageBlob: null, imageX: 0, imageY: 0, imageScale: 1,
  title: {...baseLayer, text: 'TITLE', font: fonts[33].css, x: W/2, y: 742, size: 110, vertical: 'middle'},
  author: {...baseLayer, text: 'AUTHOR', font: fonts[26].css, x: W/2, y: 1468, size: 42, spacing: 5, line: 1, vertical: 'bottom'},
  overlay: 28, linked: true, locks: {image:false,title:false,author:false}
};
let selected = 'title', drag = null, fontModalLayer = 'title';
let undoStack = [], redoStack = [];
const inputHistoryTimers={};
let db=null, currentProjectId=null, currentProjectNameOverride=null, autosaveReady=false, autosaveTimer=null, saveErrorShown=false;
const DB_NAME='covermuse-projects', STORE='projects', MAX_PROJECTS=5;

function cloneState() {
  return { image:state.image,imageBlob:state.imageBlob,imageX:state.imageX,imageY:state.imageY,imageScale:state.imageScale,title:{...state.title},author:{...state.author},overlay:state.overlay,linked:state.linked,locks:{...state.locks} };
}
function restore(s) {
  state.image=s.image; state.imageBlob=s.imageBlob; state.imageX=s.imageX; state.imageY=s.imageY; state.imageScale=s.imageScale;
  state.title={...s.title}; state.author={...s.author}; state.overlay=s.overlay; state.linked=s.linked; state.locks={image:false,title:false,author:false,...s.locks};
  syncAll(); draw();
}
function remember() { undoStack.push(cloneState()); if (undoStack.length > 50) undoStack.shift(); redoStack=[]; updateHistory(); }
function rememberInput(key){if(!inputHistoryTimers[key])remember();clearTimeout(inputHistoryTimers[key]);inputHistoryTimers[key]=setTimeout(()=>delete inputHistoryTimers[key],700);}
function undo() { if (!undoStack.length) return; redoStack.push(cloneState()); restore(undoStack.pop()); updateHistory(); }
function redo() { if (!redoStack.length) return; undoStack.push(cloneState()); restore(redoStack.pop()); updateHistory(); }
function updateHistory() { $('undoBtn').disabled=!undoStack.length; $('redoBtn').disabled=!redoStack.length; }

function openProjectsDB(){return new Promise((resolve,reject)=>{const req=indexedDB.open(DB_NAME,1);req.onupgradeneeded=()=>req.result.createObjectStore(STORE,{keyPath:'id'});req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
function dbRequest(mode,action){return new Promise((resolve,reject)=>{const tx=db.transaction(STORE,mode),store=tx.objectStore(STORE),req=action(store);req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});}
const getProjects=()=>dbRequest('readonly',s=>s.getAll());
const putProject=p=>dbRequest('readwrite',s=>s.put(p));
const removeProject=id=>dbRequest('readwrite',s=>s.delete(id));
function editorState(){return{imageX:state.imageX,imageY:state.imageY,imageScale:state.imageScale,title:{...state.title},author:{...state.author},overlay:state.overlay,linked:state.linked,locks:{...state.locks}};}
function projectTitle(){const t=state.title.text.trim().replace(/\s+/g,' ');return t&&t!=='TITLE'?t:'Untitled Cover';}
function makeThumbnail(){try{const c=document.createElement('canvas');c.width=180;c.height=288;c.getContext('2d').drawImage(canvas,0,0,c.width,c.height);return c.toDataURL('image/jpeg',.66);}catch(e){return null;}}
async function saveCurrentProject(){if(!db||!currentProjectId||!autosaveReady)return true;clearTimeout(autosaveTimer);try{await document.fonts.ready;await putProject({id:currentProjectId,name:currentProjectNameOverride||projectTitle(),updatedAt:Date.now(),editor:editorState(),imageBlob:state.imageBlob,thumbnail:makeThumbnail()});saveErrorShown=false;return true;}catch(e){if(!saveErrorShown){toast('Draft could not be saved · check phone storage');saveErrorShown=true;}return false;}}
function scheduleAutosave(){if(!autosaveReady||!currentProjectId)return;clearTimeout(autosaveTimer);autosaveTimer=setTimeout(saveCurrentProject,650);}
window.flushAutosave=()=>{saveCurrentProject();return true;};
function loadBlobImage(blob){return new Promise((resolve,reject)=>{if(!blob){resolve(null);return;}const im=new Image(),url=URL.createObjectURL(blob);im.onload=()=>{URL.revokeObjectURL(url);resolve(im);};im.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('image'));};im.src=url;});}
function applyBlankProject(clearHistory=true){state.image=null;state.imageBlob=null;state.imageX=0;state.imageY=0;state.imageScale=1;state.overlay=28;state.linked=true;state.locks={image:false,title:false,author:false};state.title={...baseLayer,text:'TITLE',font:fonts[33].css,x:W/2,y:742,size:110,vertical:'middle'};state.author={...baseLayer,text:'AUTHOR',font:fonts[26].css,x:W/2,y:1468,size:42,spacing:5,line:1,vertical:'bottom'};currentProjectNameOverride=null;if(clearHistory){undoStack=[];redoStack=[];}$('imageInput').value='';$('photoInput').value='';}
async function loadProject(id){autosaveReady=false;const p=await dbRequest('readonly',s=>s.get(id));if(!p)return;currentProjectId=id;Object.assign(state,p.editor);state.locks={image:false,title:false,author:false,...p.editor?.locks};currentProjectNameOverride=p.name&&p.name!==projectTitle()?p.name:null;state.imageBlob=p.imageBlob||null;try{state.image=await loadBlobImage(state.imageBlob);}catch(e){state.image=null;}undoStack=[];redoStack=[];autosaveReady=true;$('projectsScreen').classList.remove('open');syncAll();draw();}
async function createProject(){const projects=await getProjects();if(projects.length>=MAX_PROJECTS){alert('You already have five projects. Delete one before starting another.');return;}await saveCurrentProject();autosaveReady=false;applyBlankProject();currentProjectId=`project-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;autosaveReady=true;$('projectsScreen').classList.remove('open');syncAll();draw();await saveCurrentProject();}
async function duplicateProject(id=currentProjectId){if(!id)return;await saveCurrentProject();const projects=await getProjects();if(projects.length>=MAX_PROJECTS){alert('You already have five projects. Delete one before duplicating another.');return;}const original=projects.find(p=>p.id===id);if(!original)return;const copy={...original,id:`project-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,name:`${original.name||'Untitled Cover'} · Copy`,updatedAt:Date.now(),editor:{...original.editor,title:{...original.editor.title},author:{...original.editor.author},locks:{...original.editor.locks}}};await putProject(copy);await loadProject(copy.id);currentProjectNameOverride=copy.name;toast('Project duplicated');}
async function deleteProject(id){const projects=await getProjects(),p=projects.find(x=>x.id===id);if(!confirm(`Delete “${p?.name||'Untitled Cover'}”? This cannot be undone.`))return;clearTimeout(autosaveTimer);await removeProject(id);if(id===currentProjectId){currentProjectId=null;autosaveReady=false;applyBlankProject();syncAll();draw();}await showProjects(false);}
async function showProjects(save=true){if(save)await saveCurrentProject();const projects=(await getProjects()).sort((a,b)=>b.updatedAt-a.updatedAt);const list=$('projectsList');list.innerHTML='';$('closeProjects').hidden=!currentProjectId;if(!projects.length){const empty=document.createElement('div');empty.className='projects-empty';empty.textContent='No saved covers yet. Start your first project.';list.appendChild(empty);}projects.forEach(p=>{const card=document.createElement('div');card.className='project-card'+(p.id===currentProjectId?' current':'');if(p.thumbnail){const img=document.createElement('img');img.className='project-thumb';img.src=p.thumbnail;card.appendChild(img);}else{const blank=document.createElement('div');blank.className='project-thumb';card.appendChild(blank);}const info=document.createElement('div');info.className='project-info';const name=document.createElement('strong');name.textContent=p.name||'Untitled Cover';const time=document.createElement('span');time.textContent=new Date(p.updatedAt).toLocaleString([], {dateStyle:'medium',timeStyle:'short'});info.append(name,time);const duplicate=document.createElement('button');duplicate.className='project-duplicate';duplicate.type='button';duplicate.setAttribute('aria-label','Duplicate project');duplicate.textContent='⧉';duplicate.onclick=e=>{e.stopPropagation();duplicateProject(p.id);};const del=document.createElement('button');del.className='project-delete';del.type='button';del.setAttribute('aria-label','Delete project');del.textContent='×';del.onclick=e=>{e.stopPropagation();deleteProject(p.id);};card.append(info,duplicate,del);card.onclick=()=>loadProject(p.id);list.appendChild(card);});$('projectsScreen').classList.add('open');}

function fontString(l) { return `${l.italic?'italic ':'normal '}${l.bold?'700 ':'400 '}${l.size}px ${l.font}`; }
function linesFor(l) { return (l.caps ? l.text.toUpperCase() : l.text).split(/\n/); }
function spacedWidth(text, spacing) { const chars=[...text]; return chars.reduce((sum,c)=>sum+ctx.measureText(c).width,0)+Math.max(0,chars.length-1)*spacing; }
function metrics(l) {
  ctx.font=fontString(l);
  const lines=linesFor(l);
  const widths=lines.map(t => spacedWidth(t,l.spacing));
  return {lines,widths,width:Math.max(1,...widths),height:lines.length*l.size*l.line};
}
function leftOf(l) { const m=metrics(l); return l.align==='left'?l.x:l.align==='right'?l.x-m.width:l.x-m.width/2; }
function setAlign(layer, align) {
  const l=state[layer], left=leftOf(l), width=metrics(l).width;
  l.align=align; l.x=align==='left'?left:align==='right'?left+width:left+width/2;
}
function place(layer, position) {
  const l=state[layer], width=metrics(l).width;
  const left=position==='left'?70:position==='right'?W-70-width:(W-width)/2;
  l.position=position; l.x=l.align==='left'?left:l.align==='right'?left+width:left+width/2;
}
function placeVertical(layer, vertical) {
  const l=state[layer], height=metrics(l).height;
  l.vertical=vertical; l.y=vertical==='top'?90:vertical==='bottom'?H-90-height:(H-height)/2;
}
function reflow(layer) {
  const l=state[layer]; if(l.position!=='custom')place(layer,l.position); if(l.vertical!=='custom')placeVertical(layer,l.vertical);
}

function drawLetterSpaced(text,x,y,spacing,align,stroke) {
  const chars=[...text], widths=chars.map(c=>ctx.measureText(c).width), total=spacedWidth(text,spacing);
  let p=align==='left'?x:align==='right'?x-total:x-total/2;
  chars.forEach((c,i)=>{ stroke?ctx.strokeText(c,p,y):ctx.fillText(c,p,y); p+=widths[i]+spacing; });
}
function drawLayer(layer) {
  const l=state[layer], {lines}=metrics(l);
  ctx.save(); ctx.font=fontString(l); ctx.textBaseline='top'; ctx.fillStyle=l.color; ctx.lineJoin='round';
  if(l.shadow){ctx.shadowColor='rgba(0,0,0,.55)';ctx.shadowBlur=16;ctx.shadowOffsetY=5;}
  lines.forEach((text,i)=>{
    const y=l.y+i*l.size*l.line;
    if(l.outline){ctx.save();ctx.shadowColor='transparent';ctx.strokeStyle='rgba(0,0,0,.78)';ctx.lineWidth=Math.max(2,l.size*.045);drawLetterSpaced(text,l.x,y,l.spacing,l.align,true);ctx.restore();}
    drawLetterSpaced(text,l.x,y,l.spacing,l.align,false);
    if(l.underline){const w=spacedWidth(text,l.spacing);const sx=l.align==='left'?l.x:l.align==='right'?l.x-w:l.x-w/2;ctx.fillRect(sx,y+l.size*1.02,w,Math.max(2,l.size*.035));}
  }); ctx.restore();
}
function drawGuides() {
  if(!drag || drag.layer==='image') return;
  ctx.save();ctx.setLineDash([10,10]);ctx.lineWidth=2;
  [[70,'rgba(255,255,255,.42)'],[W/2,'rgba(255,210,95,.75)'],[W-70,'rgba(255,255,255,.42)']].forEach(([x,c])=>{ctx.strokeStyle=c;ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();});
  ctx.restore();
}
function draw(exporting=false) {
  ctx.clearRect(0,0,W,H);
  if(state.image){const im=state.image, cover=Math.max(W/im.width,H/im.height)*state.imageScale, dw=im.width*cover,dh=im.height*cover;ctx.drawImage(im,(W-dw)/2+state.imageX,(H-dh)/2+state.imageY,dw,dh);}
  else {const g=ctx.createLinearGradient(0,0,W,H);g.addColorStop(0,'#312342');g.addColorStop(.5,'#15243c');g.addColorStop(1,'#121218');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);}
  ctx.fillStyle=`rgba(0,0,0,${state.overlay/100})`;ctx.fillRect(0,0,W,H);
  drawLayer('title');drawLayer('author'); if(!exporting) drawGuides();
  if(!exporting)scheduleAutosave();
}

const categories = (items) => ['All',...new Set(items.map(x=>x.category))];
function makeChips(container, names, current, onPick) { container.innerHTML=''; names.forEach(name=>{const b=document.createElement('button');b.className='chip'+(name===current?' selected':'');b.textContent=name;b.onclick=()=>onPick(name);container.appendChild(b);}); }
let fontCategory='All';
function renderFontModal() {
  const q=$('fontModalSearch').value.trim().toLowerCase();
  makeChips($('fontModalCategories'),categories(fonts),fontCategory,c=>{fontCategory=c;renderFontModal();});
  $('fontModalList').innerHTML='';
  fonts.filter(f=>(fontCategory==='All'||f.category===fontCategory)&&f.name.toLowerCase().includes(q)).forEach(f=>{
    const b=document.createElement('button');b.className='font-option'+(state[fontModalLayer].font===f.css?' selected':'');
    const name=document.createElement('strong');name.textContent=f.name;name.style.fontFamily=f.css;
    const sample=document.createElement('span');sample.textContent=fontModalLayer==='title'?(state.title.text||'TITLE'):(state.author.text||'AUTHOR');sample.style.fontFamily=f.css;
    b.append(name,sample);b.onclick=()=>{remember();state[fontModalLayer].font=f.css;reflow(fontModalLayer);closeFontModal();syncAll();draw();};
    $('fontModalList').appendChild(b);
  });
}
function openFontModal(layer){fontModalLayer=layer;fontCategory='All';$('fontModalSearch').value='';$('fontModal').classList.add('open');$('fontModal').setAttribute('aria-hidden','false');renderFontModal();}
function closeFontModal(){$('fontModal').classList.remove('open');$('fontModal').setAttribute('aria-hidden','true');}
function fontName(css){return (fonts.find(f=>f.css===css)||{name:css.split(',')[0].replaceAll("'",'')}).name;}

const palettes=[['#fff','#f1d39b'],['#fff','#ef899e'],['#f7f0df','#ddbd72'],['#dcecff','#87b8ff'],['#fff','#c9ffdb'],['#ffe9d0','#ffad72']];
const styleCats=['Romance','Thriller','Fantasy','Minimal','Classic','Modern'];
const styles=Array.from({length:120},(_,i)=>({
  name:`${styleCats[i%6]} ${String(i+1).padStart(3,'0')}`,category:styleCats[i%6],font:fonts[(i*7+5)%fonts.length].css,
  titleColor:palettes[i%palettes.length][0],authorColor:palettes[i%palettes.length][1],
  titleSize:[78,92,108,124,142][i%5],position:['left','center','right'][i%3],align:['left','center','right'][i%3],
  y:[160,300,530,760,980][i%5],authorY:[1240,1360,1460][i%3],caps:i%4!==0,outline:i%7===0,shadow:i%5!==0
}));
let styleCategory='All';
function renderStyles(){const q=$('styleSearch').value.toLowerCase();makeChips($('styleCategories'),categories(styles),styleCategory,c=>{styleCategory=c;renderStyles();});$('presetGrid').innerHTML='';styles.filter(s=>(styleCategory==='All'||s.category===styleCategory)&&s.name.toLowerCase().includes(q)).forEach(s=>{const b=document.createElement('button');b.className='preset';b.innerHTML=`<span style="font-family:${s.font}">Aa</span><strong>${s.name}</strong>`;b.onclick=()=>{remember();Object.assign(state.title,{font:s.font,color:s.titleColor,size:s.titleSize,y:s.y,caps:s.caps,outline:s.outline,shadow:s.shadow,align:s.align,vertical:'custom'});Object.assign(state.author,{font:s.font,color:s.authorColor,y:s.authorY,align:s.align,vertical:'custom'});place('title',s.position);place('author',s.position);syncAll();draw();toast(`${s.name} applied`);};$('presetGrid').appendChild(b);});}

function syncLayer(layer){const l=state[layer],locked=!!state.locks[layer];$(layer+'Input').value=l.text;$(layer+'Size').value=l.size;$(layer+'Spacing').value=l.spacing;$(layer+'Color').value=l.color;$(layer+'Locked').checked=locked;['Bold','Italic','Underline','Shadow','Caps'].forEach(k=>$(layer+k).checked=l[k.toLowerCase()]);if(layer==='title'){$('titleLine').value=l.line;$('titleOutline').checked=l.outline;}else $('authorLine').value=l.line;const p=$(layer+'FontPicker');p.querySelector('strong').textContent=fontName(l.font);p.querySelector('strong').style.fontFamily=l.font;document.querySelectorAll(`[data-position-layer="${layer}"], [data-vertical-layer="${layer}"]`).forEach(g=>g.classList.toggle('locked-control',locked));document.querySelectorAll(`[data-position-layer="${layer}"] button`).forEach(b=>b.classList.toggle('selected',b.dataset.value===l.position));document.querySelectorAll(`[data-vertical-layer="${layer}"] button`).forEach(b=>b.classList.toggle('selected',b.dataset.value===l.vertical));document.querySelectorAll(`[data-align-layer="${layer}"] button`).forEach(b=>b.classList.toggle('selected',b.dataset.value===l.align));document.querySelectorAll(`[data-size-layer="${layer}"] button`).forEach(b=>b.classList.toggle('selected',+b.dataset.size===l.size));}
function syncAll(){syncLayer('title');syncLayer('author');$('imageLocked').checked=state.locks.image;$('zoom').disabled=state.locks.image;$('centerImage').disabled=state.locks.image;$('zoom').value=Math.round(state.imageScale*100);$('zoomValue').textContent=`${$('zoom').value}%`;$('overlay').value=state.overlay;document.querySelectorAll('.linkedMove').forEach(x=>x.checked=state.linked);updateHistory();}
function toast(msg){$('toast').textContent=msg;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),1800);}

document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>{document.querySelectorAll('[data-tab]').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('[data-tool]').forEach(x=>x.classList.toggle('active',x.dataset.tool===b.dataset.tab));selected=b.dataset.tab==='author'?'author':'title';});
['title','author'].forEach(layer=>{
  $(layer+'Input').oninput=e=>{rememberInput(layer+'Text');state[layer].text=e.target.value;if(layer==='title')currentProjectNameOverride=null;reflow(layer);draw();};
  $(layer+'FontPicker').onclick=()=>openFontModal(layer);
  ['Size','Spacing'].forEach(k=>$(layer+k).oninput=e=>{rememberInput(layer+k);state[layer][k.toLowerCase()]=+e.target.value;reflow(layer);draw();});
  $(layer+'Color').oninput=e=>{rememberInput(layer+'Color');state[layer].color=e.target.value;draw();};
  ['Bold','Italic','Underline','Shadow','Caps'].forEach(k=>$(layer+k).onchange=e=>{remember();state[layer][k.toLowerCase()]=e.target.checked;reflow(layer);draw();});
});
$('titleLine').oninput=e=>{rememberInput('titleLine');state.title.line=+e.target.value;reflow('title');draw();};
$('authorLine').oninput=e=>{rememberInput('authorLine');state.author.line=+e.target.value;reflow('author');draw();};
$('titleOutline').onchange=e=>{remember();state.title.outline=e.target.checked;draw();};
function insertLineBreak(layer){const input=$(layer+'Input'),start=input.selectionStart??input.value.length,end=input.selectionEnd??start;remember();input.value=input.value.slice(0,start)+'\n'+input.value.slice(end);state[layer].text=input.value;if(layer==='title')currentProjectNameOverride=null;reflow(layer);draw();input.focus();input.setSelectionRange(start+1,start+1);}
$('titleNewLine').onclick=()=>insertLineBreak('title');$('authorNewLine').onclick=()=>insertLineBreak('author');
['image','title','author'].forEach(layer=>{$(layer+'Locked').onchange=e=>{remember();state.locks[layer]=e.target.checked;syncAll();draw();toast(`${layer[0].toUpperCase()+layer.slice(1)} ${e.target.checked?'locked':'unlocked'}`);};});
document.querySelectorAll('.size-choices button').forEach(b=>b.onclick=()=>{const layer=b.closest('[data-size-layer]').dataset.sizeLayer;remember();state[layer].size=+b.dataset.size;reflow(layer);syncAll();draw();});
document.querySelectorAll('[data-position-layer] button').forEach(b=>b.onclick=()=>{const layer=b.closest('[data-position-layer]').dataset.positionLayer;if(state.locks[layer]){toast(`${layer==='title'?'Title':'Author'} position is locked`);return;}remember();place(layer,b.dataset.value);syncAll();draw();});
document.querySelectorAll('[data-vertical-layer] button').forEach(b=>b.onclick=()=>{const layer=b.closest('[data-vertical-layer]').dataset.verticalLayer;if(state.locks[layer]){toast(`${layer==='title'?'Title':'Author'} position is locked`);return;}remember();placeVertical(layer,b.dataset.value);syncAll();draw();});
document.querySelectorAll('[data-align-layer] button').forEach(b=>b.onclick=()=>{const layer=b.closest('[data-align-layer]').dataset.alignLayer;remember();setAlign(layer,b.dataset.value);syncAll();draw();});

async function optimizedImageBlob(file){const im=await loadBlobImage(file),max=3000,scale=Math.min(1,max/Math.max(im.width,im.height));if(scale===1)return file;const c=document.createElement('canvas');c.width=Math.round(im.width*scale);c.height=Math.round(im.height*scale);c.getContext('2d').drawImage(im,0,0,c.width,c.height);return await new Promise(resolve=>c.toBlob(resolve,'image/jpeg',.92));}
async function chooseImage(e){const file=e.target.files&&e.target.files[0];if(!file)return;try{const blob=await optimizedImageBlob(file),im=await loadBlobImage(blob);remember();state.imageBlob=blob;state.image=im;state.imageScale=1;state.imageX=state.imageY=0;syncAll();draw();toast('Image added');}catch(err){toast('That image could not be opened');}e.target.value='';}
$('imageInput').onchange=chooseImage;$('photoInput').onchange=chooseImage;
$('zoom').oninput=e=>{if(state.locks.image)return;rememberInput('imageZoom');state.imageScale=+e.target.value/100;$('zoomValue').textContent=`${e.target.value}%`;draw();};
$('centerImage').onclick=()=>{if(state.locks.image){toast('Image position is locked');return;}remember();state.imageX=state.imageY=0;state.imageScale=1;syncAll();draw();};
$('overlay').oninput=e=>{rememberInput('overlay');state.overlay=+e.target.value;draw();};
document.querySelectorAll('.linkedMove').forEach(box=>{box.checked=state.linked;box.onchange=e=>{remember();state.linked=e.target.checked;document.querySelectorAll('.linkedMove').forEach(x=>x.checked=state.linked);};});
$('styleSearch').oninput=renderStyles;$('fontModalSearch').oninput=renderFontModal;
$('closeFontModal').onclick=closeFontModal;$('fontModal').onclick=e=>{if(e.target===$('fontModal'))closeFontModal();};
$('undoBtn').onclick=undo;$('redoBtn').onclick=redo;
$('resetBtn').onclick=()=>{if(!confirm('Reset this project? This removes its image and all edits.'))return;remember();applyBlankProject(false);$('appMenu').removeAttribute('open');syncAll();draw();toast('Project reset');};

function point(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*W/r.width,y:(e.clientY-r.top)*H/r.height};}
function hitLayer(p,layer){const l=state[layer],m=metrics(l),left=leftOf(l);return p.x>=left-25&&p.x<=left+m.width+25&&p.y>=l.y-25&&p.y<=l.y+m.height+35;}
canvas.onpointerdown=e=>{const p=point(e);let layer=hitLayer(p,'title')?'title':hitLayer(p,'author')?'author':state.image?'image':null;if(!layer)return;if(state.locks[layer]){toast(`${layer[0].toUpperCase()+layer.slice(1)} position is locked`);return;}remember();drag={layer,last:p};canvas.setPointerCapture(e.pointerId);draw();};
canvas.onpointermove=e=>{if(!drag)return;const p=point(e),dx=p.x-drag.last.x,dy=p.y-drag.last.y;if(drag.layer==='image'){state.imageX+=dx;state.imageY+=dy;}else{const layers=(state.linked?['title','author']:[drag.layer]).filter(k=>!state.locks[k]);layers.forEach(k=>{state[k].x+=dx;state[k].y+=dy;state[k].position='custom';state[k].vertical='custom';});}drag.last=p;draw();};
canvas.onpointerup=canvas.onpointercancel=()=>{drag=null;syncAll();draw();};

function download(data,name,type){if(window.Android?.saveImage){window.Android.saveImage(data,name,type);toast('Saved to Downloads');return;}const a=document.createElement('a');a.href=data;a.download=name;a.click();toast(`${name} saved`);}
async function exportCover(kind,small=false){await document.fonts.ready;draw(true);let source=canvas,quality=.94;if(small){source=document.createElement('canvas');source.width=650;source.height=1040;source.getContext('2d').drawImage(canvas,0,0,650,1040);quality=.78;}const type=kind==='png'?'image/png':'image/jpeg';download(source.toDataURL(type,quality),`CoverMuse-${Date.now()}${small?'-reader':''}.${kind==='png'?'png':'jpg'}`,type);draw();}
$('exportJpg').onclick=()=>exportCover('jpg');$('exportSmallJpg').onclick=()=>exportCover('jpg',true);$('exportPng').onclick=()=>exportCover('png');
$('quickSave').onclick=()=>{$('appMenu').removeAttribute('open');exportCover('jpg');};
$('menuProjects').onclick=()=>{$('appMenu').removeAttribute('open');showProjects();};
$('menuNewProject').onclick=()=>{$('appMenu').removeAttribute('open');createProject();};
$('menuDuplicateProject').onclick=()=>{$('appMenu').removeAttribute('open');duplicateProject();};
$('newProjectBtn').onclick=createProject;$('closeProjects').onclick=()=>$('projectsScreen').classList.remove('open');

window.handleAndroidBack=()=>{const e=document.activeElement,typing=e&&(e.tagName==='TEXTAREA'||(e.tagName==='INPUT'&&['text','search','email','url','number'].includes(e.type)));if(typing){e.blur();setTimeout(()=>window.scrollTo(0,0),50);return'handled';}if($('fontModal').classList.contains('open')){closeFontModal();return'handled';}if($('appMenu').hasAttribute('open')){$('appMenu').removeAttribute('open');return'handled';}if($('projectsScreen').classList.contains('open')&&currentProjectId){$('projectsScreen').classList.remove('open');return'handled';}const hasDraft=!!currentProjectId;saveCurrentProject().then(ok=>{if(window.Android?.showExitDialog)window.Android.showExitDialog(hasDraft&&ok);});return'saving';};
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')saveCurrentProject();});

async function initApp(){renderStyles();syncAll();draw();try{db=await openProjectsDB();await showProjects(false);}catch(e){toast('Project storage is unavailable');currentProjectId=`temporary-${Date.now()}`;autosaveReady=false;$('projectsScreen').classList.remove('open');}}
initApp();
