package com.covermuse.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.DownloadListener;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int FILE_REQUEST = 42;
    private ValueCallback<Uri[]> fileCallback;
    private WebView view;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        view = new WebView(this);
        setContentView(view);
        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        view.setWebViewClient(new WebViewClient());
        view.addJavascriptInterface(new Object() {
            @JavascriptInterface public void saveImage(String dataUrl, String filename, String mime) {
                try {
                    byte[] bytes = Base64.decode(dataUrl.substring(dataUrl.indexOf(',') + 1), Base64.DEFAULT);
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, filename);
                    values.put(MediaStore.Images.Media.MIME_TYPE, mime);
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/CoverMuse");
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) { out.write(bytes); }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Saved to Pictures/CoverMuse", Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Could not save cover", Toast.LENGTH_LONG).show());
                }
            }
            @JavascriptInterface public void showExitDialog(boolean draftSaved) {
                runOnUiThread(() -> showExitDialogNative(draftSaved));
            }
        }, "Android");
        view.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                boolean useFiles = false;
                for (String type : params.getAcceptTypes()) {
                    if (type != null && type.contains("application/x-covermuse-files")) useFiles = true;
                }
                Intent intent;
                if (useFiles) {
                    intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("image/*");
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(Intent.createChooser(intent, "Choose image file"), FILE_REQUEST);
                } else if (Build.VERSION.SDK_INT >= 33) {
                    intent = new Intent(MediaStore.ACTION_PICK_IMAGES);
                    intent.setType("image/*");
                    startActivityForResult(intent, FILE_REQUEST);
                } else {
                    intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    intent.setType("image/*");
                    startActivityForResult(Intent.createChooser(intent, "Choose from Photos"), FILE_REQUEST);
                }
                return true;
            }
        });
        view.setDownloadListener((url, agent, disposition, mime, length) -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        });
        view.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == FILE_REQUEST && fileCallback != null) {
            Uri[] value = result == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(value);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        view.evaluateJavascript("window.handleAndroidBack?window.handleAndroidBack():'exit'", value -> {
            if ("\"handled\"".equals(value)) {
                InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                keyboard.hideSoftInputFromWindow(view.getWindowToken(), 0);
                view.requestFocus();
            }
        });
    }

    private void showExitDialogNative(boolean draftSaved) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
            .setTitle(draftSaved ? "Draft saved" : "Exit CoverMuse?")
            .setNegativeButton("Stay", null)
            .setPositiveButton("Exit", (d, which) -> finish());
        if (draftSaved) dialog.setMessage("Your current project has been saved automatically.");
        dialog.show();
    }

    @Override protected void onPause() {
        if (view != null) view.evaluateJavascript("window.flushAutosave&&window.flushAutosave()", null);
        super.onPause();
    }
}
