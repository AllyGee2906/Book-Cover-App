import re, sys, urllib.parse, urllib.request
from pathlib import Path

families = [
'Abril Fatface','Alegreya','Alegreya Sans','Alfa Slab One','Alice','Amatic SC','Anton','Archivo','Arimo','Arvo','Assistant','Bangers','Barlow','Barlow Condensed','Bebas Neue','Bitter','Bodoni Moda','Bree Serif','Cabin','Cardo','Catamaran','Caveat','Cinzel','Comfortaa','Cormorant','Cormorant Garamond','Courier Prime','Crimson Pro','Crimson Text','Dancing Script','DM Sans','DM Serif Display','Domine','Dosis','EB Garamond','Exo 2','Faustina','Fira Sans','Fjalla One','Forum','Fraunces','Fredoka','Great Vibes','Heebo','IBM Plex Mono','IBM Plex Sans','IBM Plex Serif','Inconsolata','Inter','Josefin Sans','Josefin Slab','Jost','Kalam','Kanit','Karla','Kaushan Script','Lato','League Gothic','Libre Baskerville','Libre Caslon Display','Libre Franklin','Lobster','Lora','Manrope','Merriweather','Merriweather Sans','Montserrat','Mulish','Nanum Myeongjo','Noto Sans','Noto Serif','Nunito','Old Standard TT','Open Sans','Orbitron','Oswald','Outfit','Overpass','Pacifico','Parisienne','Patrick Hand','Permanent Marker','Philosopher','Playfair Display','Plus Jakarta Sans','Poppins','Prata','Prompt','PT Sans','PT Serif','Quicksand','Raleway','Roboto','Roboto Condensed','Roboto Mono','Roboto Slab','Rock Salt','Rokkitt','Rubik','Sacramento','Satisfy','Shadows Into Light','Signika','Slabo 27px','Source Code Pro','Source Sans 3','Source Serif 4','Space Grotesk','Special Elite','Spectral','Teko','Tenor Sans','Titillium Web','Ubuntu','Ubuntu Condensed','Unbounded','Varela Round','Vollkorn','Work Sans','Yanone Kaffeesatz']
dest=Path(sys.argv[1]); font_dir=dest/'fonts-google'; font_dir.mkdir(parents=True,exist_ok=True)
blocks=[]; sample='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,!?&'; headers={'User-Agent':'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36'}
for i,family in enumerate(families):
    try:
        query=urllib.parse.urlencode({'family':family,'text':sample})
        css=urllib.request.urlopen(urllib.request.Request('https://fonts.googleapis.com/css2?'+query,headers=headers),timeout=30).read().decode()
        url=re.search(r'url\((https://[^)]+)\)',css).group(1); ext='.woff2' if 'woff2' in css else '.ttf'; name=f'f{i:03d}{ext}'
        (font_dir/name).write_bytes(urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30).read())
        blocks.append(f"@font-face{{font-family:'{family}';src:url('fonts-google/{name}');font-display:swap}}")
    except Exception as exc: print(f'warning: {family}: {exc}')
(dest/'google-fonts.css').write_text('\n'.join(blocks),encoding='utf-8'); print(f'Downloaded {len(blocks)} of {len(families)} fonts')
