import re, sys, urllib.parse, urllib.request
from pathlib import Path

dest=Path(sys.argv[1]); font_dir=dest/'fonts-google'; font_dir.mkdir(parents=True,exist_ok=True)
app_js=(dest/'app.js').read_text(encoding='utf-8')
family_block=re.search(r'const familyNames\s*=\s*\[([\s\S]*?)\];',app_js).group(1)
families=re.findall(r"'([^']+)'",family_block)
blocks=[]; sample='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789.,!?&'; headers={'User-Agent':'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36'}
for i,family in enumerate(families):
    try:
        query=urllib.parse.urlencode({'family':family,'text':sample})
        css=urllib.request.urlopen(urllib.request.Request('https://fonts.googleapis.com/css2?'+query,headers=headers),timeout=30).read().decode()
        url=re.search(r'url\((https://[^)]+)\)',css).group(1); ext='.woff2' if 'woff2' in css else '.ttf'; name=f'f{i:03d}{ext}'
        (font_dir/name).write_bytes(urllib.request.urlopen(urllib.request.Request(url,headers=headers),timeout=30).read())
        blocks.append(f"@font-face{{font-family:'{family}';src:url('fonts-google/{name}');font-display:swap}}")
    except Exception as exc: print(f'warning: {family}: {exc}')
(dest/'google-fonts.css').write_text('\n'.join(blocks),encoding='utf-8'); print(f'Downloaded {len(blocks)} of {len(families)} fonts')
