# CoverMuse

An offline-first, touch-friendly book-cover typography editor. Users add their own artwork, style and drag title/author layers, apply curated layout presets, and export a clean 1000 × 1600 JPG or PNG.

## Run locally

Serve this folder from any static web server, for example `python3 -m http.server 8080`, then open `http://localhost:8080`.

The app is installable as a PWA in Android browsers. Its HTML/CSS/JavaScript assets are also ready to bundle into an Android WebView wrapper.

## Android Studio build

Open the `android` folder in Android Studio, let Gradle sync, and select **Build → Build APK(s)**. The editor is bundled in `app/src/main/assets`, so the installed app works without a server or internet connection.

## V1 features

- Portrait 5:8 book-cover canvas
- Artwork upload, crop positioning, and zoom
- Independent title and author styling
- Eight offline font families
- Multi-line titles, letter spacing, line spacing, alignment, colour, shadow, outline, and caps
- Drag-to-position text and artwork
- Four quick typography presets
- High-resolution JPG and PNG export
- Fully offline after first load
